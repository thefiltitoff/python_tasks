from setuptools import setup

setup(
    name="study_package",
    version="0.0.1",
    author="Felix",
    packages=["study_package"],
    description="This is a test package for python practice"
)